<?php
$db_host = 'localhost';
$db_name = 'powerdns';
$db_user = 'admin';
$db_pass = 'VinahostP@ssw0rd!@#456';
$db_type = 'mysql';

$session_key = 'kw6FqN*wl%*hCapDRFK32s@yjjffW!T^)BX0!mj8bvv(y_';

$iface_lang = 'en_EN';

$dns_hostmaster = 'nsmaster.premium-dns.vinahost.vn';
$dns_ns1 = 'ns1.premium-dns.vinahost.vn';
$dns_ns2 = 'ns2.premium-dns.vinahost.vn';

$ignore_install_dir = true;
