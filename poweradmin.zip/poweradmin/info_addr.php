<?php
$ip = $_SERVER['REMOTE_ADDR'];
echo "Địa chỉ IP của client truy cập là: " . $ip;
?>
