<?php

$db_type = '%dbType%';
$db_file = '%dbFile%';
$db_host = '%dbHost%';
$db_port = '%dbPort%';
$db_user = '%dbUser%';
$db_pass = '%dbPassword%';
$db_name = '%dbName%';
$db_charset = '%dbCharset%';

$session_key = '%sessionKey%';
$iface_lang = '%locale%';

$dns_hostmaster = '%hostMaster%';
$dns_ns1 = '%primaryNameServer%';
$dns_ns2 = '%secondaryNameServer%';
$dns_ns3 = '%thirdNameServer%';
$dns_ns4 = '%fourthNameServer%';

$ignore_install_dir = true;
